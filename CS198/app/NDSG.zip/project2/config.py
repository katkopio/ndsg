class Config:
	SECRET_KEY = '824fb3bf0f538824c22fe8b8e26a2596'
	SQLALCHEMY_DATABASE_URI = 'sqlite:///site.db'
	UPLOAD_FOLDER = 'project2/static/gpx'
